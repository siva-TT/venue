// ignore_for_file: deprecated_member_use

import 'dart:async';

import 'package:venuestar/vnu/presentation/common/root_screen.dart';
import 'package:venuestar/vnu/presentation/fnb/view/fnb_page.dart';
import 'package:venuestar/vnu/presentation/home/view/home_page.dart';
import 'package:venuestar/vnu/presentation/more/more_page.dart';
import 'package:venuestar/vnu/presentation/whatson/view/whatson_page.dart';
import 'package:venuestar/vnu/simple_bloc_observer.dart';
import 'package:venuestar/vnu/theme/theme.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:rxcommon/presentation/navigation/navigation.dart';

import 'injection.dart' as di;

void main() async {
  di.init();

  runZonedGuarded<Future<void>>(() async {
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
    BlocOverrides.runZoned(
      () => runApp(const App()),
      blocObserver: SimpleBlocObserver(),
    );
  }, (error, stack) {
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
  });
}

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<NavigationCubit>(
      create: (context) => NavigationCubit(),
      child: MaterialApp(
        title: 'Named Routes',
        debugShowCheckedModeBanner: false,
        theme: lightTheme,
        initialRoute: '/',
        routes: {
          '/': (context) => RootScreen(),
          '/whatson': (context) => const WhatsonPage(),
          // '/homepage': (context) => const HomePage(),
          '/fnbpage': (context) => const FnbPage(),
          '/morepage': (context) => const MorePage(),
        },
      ),
    );
  }
}
