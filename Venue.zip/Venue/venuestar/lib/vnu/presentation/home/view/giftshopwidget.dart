import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rxcommon/lib.dart';
import 'package:shimmer/shimmer.dart';
import 'package:venuestar/vnu/constant/constant.dart';
import 'package:venuestar/vnu/constant/strings.dart';
import 'package:venuestar/vnu/presentation/common/widgets/item_interest_widget.dart';
import 'package:venuestar/vnu/constant/custom_text_style.dart';
import 'package:venuestar/vnu/presentation/common/widgets/textfield.dart';

class GiftshopList extends StatefulWidget {
  const GiftshopList({Key? key}) : super(key: key);

  @override
  State<GiftshopList> createState() => _GiftshopListState();
}

class _GiftshopListState extends State<GiftshopList> {
  @override
  void initState() {
    super.initState();
    getGiftshop();
  }

  Future<void> getGiftshop() async {
    context.read<GiftShopBloc>().add(GiftShopFetched());
  }

  Widget placeholder() {
    return Shimmer.fromColors(
        baseColor: Colors.grey,
        highlightColor: Colors.grey.shade300,
        child: SizedBox(
          height: Constant.homeWidgetImage,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 2, //state.posts.length,
            itemBuilder: (BuildContext ctx, index) {
              return ItemInterest(
                  title: "",
                  previewImagePath: "",
                  actionDescription: "",
                  itemType: "",
                  sysId: "",
                  transId: "",
                  extUrl: "");
            },
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GiftShopBloc, GiftShopState>(builder: (context, state) {
      int pos = state.posts.length;
      if (state.status == GiftShopStatus.initial) {
        return placeholder();
      }

      if (state.status == GiftShopStatus.loading) {
        return placeholder();
      }

      if (state.status == GiftShopStatus.error) {
        return placeholder();
      }

      if (pos > 3) pos = 3;

      return Container(
        child: Column(children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              if (state.posts.length > 0)
                Padding(
                  padding: EdgeInsets.only(left: Constant.padding15),
                  child: HomeWidgettitle(context, Strings.titlegiftshop),
                ),
              if (state.posts.length > 3)
                InkWell(
                  onTap: () => {print('Viewmore is clicked')},
                  child: Text.rich(
                    TextSpan(
                      style: CustomTextStyle.getDescStyle(Colors.white),
                      children: const [
                        TextSpan(
                          text: Strings.titleViewMore,
                        ),
                        WidgetSpan(
                          alignment: PlaceholderAlignment.middle,
                          child: Icon(
                            Icons.arrow_forward_rounded,
                            color: Colors.white,
                            size: 17,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(
              height: Constant.homeWidgetImage,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: pos, //state.posts.length,
                itemBuilder: (BuildContext ctx, index) {
                  return ItemInterest(
                      title: state.posts[index].title,
                      previewImagePath: state.posts[index].previewImagePath,
                      actionDescription: "",
                      itemType: "",
                      sysId: "",
                      transId: state.posts[index].transactionId,
                      extUrl: "");
                },
              )),
        ]),
      );
    });
  }
}
