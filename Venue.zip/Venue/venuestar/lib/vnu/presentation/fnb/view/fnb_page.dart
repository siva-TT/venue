import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rxcommon/presentation/presentation.dart';
import 'package:shimmer/shimmer.dart';
import 'package:venuestar/vnu/constant/constant.dart';
import 'package:venuestar/vnu/constant/strings.dart';
import 'package:venuestar/vnu/injection.dart';
import 'package:venuestar/vnu/presentation/common/widgets/item_card_widget.dart';
import 'package:venuestar/vnu/presentation/common/widgets/textfield.dart';

class FnbPage extends StatefulWidget {
  const FnbPage({Key? key}) : super(key: key);

  @override
  State<FnbPage> createState() => _FnbPageState();
}

class _FnbPageState extends State<FnbPage> {
  late final ItemBloc itemBloc;
  @override
  Widget build(BuildContext context) {
    return HomeScaffold(
        context, Strings.titlefnb, "fnb_header.png", blocProvider(), 0);
  }
}

Widget blocProvider() {
  return BlocProvider(
      create: (_) => FnbBloc(locator()), child: const FnbList());
}

class FnbList extends StatefulWidget {
  const FnbList({Key? key}) : super(key: key);

  @override
  State<FnbList> createState() => _FnbListState();
}

class _FnbListState extends State<FnbList> {
  @override
  void initState() {
    super.initState();
    getFnb();
  }

  Future<void> getFnb() async {
    context.read<FnbBloc>().add(FnbFetched());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FnbBloc, FnbState>(builder: (context, state) {
      if (state.status == FnbStatus.initial) {
        return Skeleton();
      }

      if (state.status == FnbStatus.loading) {
        return Skeleton();
      }

      if (state.status == FnbStatus.error) {
        return emptyResponse(context, Strings.noFnb);
      }

      return RefreshIndicator(
        onRefresh: getFnb,
        child: Column(children: <Widget>[
          Expanded(
            child: ListView.builder(
                shrinkWrap: true,
                key: const Key('Item data'),
                itemCount: state.posts.length,
                itemBuilder: (context, index) {
                  return ItemCard(
                      title: state.posts[index].title,
                      previewImagePath: state.posts[index].previewImagePath,
                      actionDescription: state.posts[index].actionDescription,
                      itemType: state.posts[index].itemType,
                      sysId: state.posts[index].venueid,
                      transId: state.posts[index].transacId,
                      extUrl: state.posts[index].extUrl,
                      description: state.posts[index].description,
                      startDate: state.posts[index].startDate,
                      endDate: state.posts[index].endDate,
                      interest: state.posts[index].interest);
                }),
          )
        ]),
      );
    });
  }
}

class Skeleton extends StatelessWidget {
  const Skeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        shrinkWrap: true,
        key: const Key('Item data'),
        itemCount: 5,
        itemBuilder: (context, index) {
          return Shimmer.fromColors(
              baseColor: Colors.grey,
              highlightColor: Colors.grey.shade300,
              child: Padding(
                padding: const EdgeInsets.only(
                    left: Constant.padding05, right: Constant.padding05),
                child: Card(
                    color: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(Constant.cornerRadius10),
                    ),
                    child: Row(children: <Widget>[
                      Container(
                        height: Constant.cardHeight119,
                        width: Constant.cardWidth10,
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(Constant.cornerRadius08),
                            bottomLeft:
                                Radius.circular(Constant.cornerRadius08),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          child: Padding(
                            padding: const EdgeInsets.only(
                                left: Constant.padding10,
                                bottom: Constant.padding05,
                                right: Constant.padding10,
                                top: Constant.padding05),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                SizedBox(
                                    height: Constant.cardHeight19,
                                    child: ListView.builder(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      scrollDirection: Axis.horizontal,
                                      itemCount: 1,
                                      itemBuilder: (BuildContext ctx, index) {
                                        return Column(children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                right: Constant.padding05),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        Constant
                                                            .cornerRadius10),
                                              ),
                                              height: Constant.cardHeight14,
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: Constant.padding05,
                                                    right: Constant
                                                        .padding05), //apply padding to all four sides
                                                child: Align(
                                                  alignment: Alignment.center,
                                                  child: Card(
                                                    child: Container(
                                                      height: 10,
                                                      width: 80,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ]);
                                      },
                                    )),
                                SizedBox(
                                  height: Constant.cardHeight48,
                                  child: Align(
                                    alignment: Alignment.topLeft,
                                    child: Column(
                                      children: [
                                        Card(
                                          child: Container(
                                            height: 7,
                                            width: 300,
                                          ),
                                        ),
                                        Card(
                                          child: Container(
                                            height: 7,
                                            width: 300,
                                          ),
                                        ),
                                        Card(
                                          child: Container(
                                            height: 7,
                                            width: 300,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: Constant.cardHeight22,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: Constant.borderWidth02,
                                        bottom: Constant.borderWidth02),
                                    child: Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Card(
                                        child: Container(
                                          height: 10,
                                          width: 150,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: Constant.cardHeight119,
                        width: Constant.cardHeight119,
                        color: Colors.transparent,
                        child: Stack(children: <Widget>[
                          Container(
                            height: Constant.cardHeight119,
                            width: Constant.cardWidth120,
                            decoration: BoxDecoration(
                              border: Border.all(
                                  color: Colors.white,
                                  width: Constant.borderWidth13),
                              borderRadius: const BorderRadius.only(
                                topRight:
                                    Radius.circular(Constant.cornerRadius08),
                                bottomRight:
                                    Radius.circular(Constant.cornerRadius08),
                              ),
                            ),
                          ),
                          Center(
                            child: SizedBox(
                              height: Constant.cardHeight98,
                              width: Constant.cardHeight98,
                              child: ClipRRect(
                                // ignore: sort_child_properties_last

                                borderRadius: BorderRadius.circular(
                                    Constant.cornerRadius12),
                              ),
                            ),
                          ),
                          Center(
                            child: Container(
                              height: Constant.cardHeight104,
                              width: Constant.cardHeight104,
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.white,
                                    width: Constant.borderWidth02),
                                borderRadius: BorderRadius.circular(
                                    Constant.cornerRadius18),
                              ),
                            ),
                          )
                        ]),
                      ),
                    ])),
              ));
        });
  }
}
