


// ignore_for_file: prefer_interpolation_to_compose_strings

class Strings {

static const String offerExpire = "Offer expire ";
static const String titleMore = "More";
static const String titlefnb = "EAT&DRINK";
static const String titlegiftshop = "GIFTSHOP";
static const String titlewelcome = "Welcome";
static const String titleRegisterhere = "REGISTER HERE";
static const String titleMyWallet = "MY WALLET";
static const String titleWhatson = "WHAT'S ON";
static const String titleViewMore = "VIEW MORE";
static const String noMoreItem = "NO MORE";
static const String nowhatson = "CHECK AGAIN SOON FOR MORE OF YOUR FAVOURITE CONTENT";
static const String noFnb = "NO EAT & DRINKS";
static const String memberReg = "Register";
static const String guestReg = "GUEST DETAILS";
static const String membershipNumber = "Membership Number";
static const String postalCode = "Postal Code";
static const String firstName = "First name";
static const String lastName = "Last name";
static const String useMyname = "Use my name";
static const String useMynumber = "Use my Twin Stars member number";
static const String date = "Date";
static const String month = "Month";
static const String year = "Year";
static const String phoneNumber = "Phone number";
static const String email = "Email";
static const String clickHere = "Click here";
static const String termsandconditionmsg = " to view our terms & conditions";
static const String contiueasGuest = "Continue as a guest";

static const String memberRegtitle = "Please register to access a range of instant discounts and benefits";
static const String guestRegtitle = "Are you already a member? Go back to register with your member info. Hint, register using your member number, DOB and postcode";
static const String guestNote = "You are registering as a guest of Twinstars Group and NOT as a member. Click register to continue as a guest or go back to register with your member info";

}

