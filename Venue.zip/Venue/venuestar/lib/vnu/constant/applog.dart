import 'package:flutter/material.dart';

class Applog {
 

 static printlog(String msg)
 {
    print('vnusample $msg');
 }

}
