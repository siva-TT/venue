


// ignore_for_file: prefer_interpolation_to_compose_strings

class LocalImages {
 

static const String assetImage = "assets/images/";

static const String homebg = assetImage+"home_bg.png";
static const String placholderImagepath = assetImage+"header_twinstars.png";
static const String whatson_ = assetImage+"whatson_.png";
static const String whatsonhover = assetImage+"whatson_hover.png";
static const String favourite_ = assetImage+"favourite_.png";
static const String favouritehover = assetImage+"favourite_hover.png";
static const String home_ = assetImage+"home_.png";
static const String homehover = assetImage+"home_hover.png";
static const String profile_ = assetImage+"profile_.png";
static const String profilehover = assetImage+"profile_hover.png";
static const String offers_ = assetImage+"offers_.png";
static const String offershover = assetImage+"offers_hover.png";
static const String products_ = assetImage+"products_.png";
static const String productshover = assetImage+"products_hover.png";

}
