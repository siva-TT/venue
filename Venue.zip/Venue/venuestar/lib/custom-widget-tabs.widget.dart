import "package:flutter/material.dart";
import 'package:flutter_svg/flutter_svg.dart';
import "package:persistent_bottom_nav_bar/persistent_tab_view.dart";
import 'package:venuestar/main.dart';
import 'package:venuestar/profile.dart';
import 'package:venuestar/screens/Navbar.dart';
// import 'package:venuestar/screens/home.dart';
import 'package:venuestar/screens/sample.dart';
import 'package:venuestar/vnu/presentation/home/view/home_page.dart';

class CustomWidgetExample extends StatefulWidget {
  const CustomWidgetExample({final Key? key, required this.menuScreenContext})
      : super(key: key);
  final BuildContext menuScreenContext;

  @override
  _CustomWidgetExampleState createState() => _CustomWidgetExampleState();
}

class _CustomWidgetExampleState extends State<CustomWidgetExample> {
  late PersistentTabController _controller;
  late bool _hideNavBar;

  @override
  void initState() {
    super.initState();
    _controller = PersistentTabController();
    _hideNavBar = false;
  }

  List<Widget> _buildScreens() => [
        HomePage(
          menuScreenContext: widget.menuScreenContext,
          hideStatus: _hideNavBar,
          onScreenHideButtonPressed: () {
            setState(() {
              _hideNavBar = !_hideNavBar;
            });
          },
        ),
        ProfilePage(
          menuScreenContext: widget.menuScreenContext,
          hideStatus: _hideNavBar,
          onScreenHideButtonPressed: () {
            setState(() {
              _hideNavBar = !_hideNavBar;
            });
          },
        ),
        SamplePage(
          menuScreenContext: widget.menuScreenContext,
          hideStatus: _hideNavBar,
          onScreenHideButtonPressed: () {
            setState(() {
              _hideNavBar = !_hideNavBar;
            });
          },
        ),
        SamplePage(
          menuScreenContext: widget.menuScreenContext,
          hideStatus: _hideNavBar,
          onScreenHideButtonPressed: () {
            setState(() {
              _hideNavBar = !_hideNavBar;
            });
          },
        ),
        SamplePage(
          menuScreenContext: widget.menuScreenContext,
          hideStatus: _hideNavBar,
          onScreenHideButtonPressed: () {
            setState(() {
              _hideNavBar = !_hideNavBar;
            });
          },
        ),
      ];

  List<PersistentBottomNavBarItem> _navBarsItems() => [
        PersistentBottomNavBarItem(
          icon: SvgPicture.asset(
            'assets/icons/home.svg',
            color: Color(0xFFB7852F),
            height: 24,
            width: 24,
          ),
          title: "Home",
          activeColorPrimary: Color(0xFFB7852F),
          inactiveColorPrimary: Colors.grey,
          inactiveIcon: SvgPicture.asset(
            'assets/icons/home.svg',
            color: Colors.grey,
            height: 24,
            width: 24,
          ),
        ),
        PersistentBottomNavBarItem(
          icon: SvgPicture.asset(
            'assets/icons/Profile.svg',
            color: Color(0xFFB7852F),
            height: 24,
            width: 24,
          ),
          title: "Profile",
          activeColorPrimary: Color(0xFFB7852F),
          inactiveColorPrimary: Colors.grey,
          inactiveIcon: SvgPicture.asset(
            'assets/icons/Profile.svg',
            color: Colors.grey,
            height: 24,
            width: 24,
          ),
        ),
        PersistentBottomNavBarItem(
          icon: SvgPicture.asset(
            'assets/icons/gift.svg',
            color: Color(0xFFB7852F),
            height: 24,
            width: 24,
          ),
          title: "Gift",
          activeColorPrimary: Color(0xFFB7852F),
          inactiveColorPrimary: Colors.grey,
          inactiveIcon: SvgPicture.asset(
            'assets/icons/gift.svg',
            color: Colors.grey,
            height: 24,
            width: 24,
          ),
        ),
        PersistentBottomNavBarItem(
          icon: SvgPicture.asset(
            'assets/icons/Favourites.svg',
            color: Color(0xFFB7852F),
            height: 24,
            width: 24,
          ),
          title: "Favourites",
          activeColorPrimary: Color(0xFFB7852F),
          inactiveColorPrimary: Colors.grey,
          inactiveIcon: SvgPicture.asset(
            'assets/icons/Favourites.svg',
            color: Colors.grey,
            height: 24,
            width: 24,
          ),
        ),
        PersistentBottomNavBarItem(
          icon: SvgPicture.asset(
            'assets/icons/More.svg',
            color: Color(0xFFB7852F),
            height: 24,
            width: 24,
          ),
          title: "More",
          activeColorPrimary: Color(0xFFB7852F),
          inactiveColorPrimary: Colors.grey,
          inactiveIcon: SvgPicture.asset(
            'assets/icons/More.svg',
            color: Colors.grey,
            height: 24,
            width: 24,
          ),
        ),
      ];

  @override
  Widget build(final BuildContext context) => Scaffold(
        body: PersistentTabView.custom(
          context,
          controller: _controller,
          // ignore: avoid_redundant_argument_values
          backgroundColor: const Color.fromARGB(255, 0, 0, 0),
          screens: _buildScreens(),
          itemCount: 5,
          hideNavigationBar: _hideNavBar,

          screenTransitionAnimation: const ScreenTransitionAnimation(
            animateTabTransition: true,
          ),
          customWidget: CustomNavBarWidget(
            _navBarsItems(),
            onItemSelected: (final index) {
              setState(() {
                _controller.index = index; // THIS IS CRITICAL!! Don't miss it!
              });
            },
            selectedIndex: _controller.index,
          ),
        ),
      );
}
