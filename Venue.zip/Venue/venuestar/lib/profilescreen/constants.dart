class Constants {
  Constants._();
  static const double padding = 20;
  static const double avatarRadius = 45;
  static const String heading = "EDIT PROFILE";
  static const String renew = "RENEW";
  static const String logout = "LOGOUT";
  static const String myprofile = "MY PROFILE";
}
