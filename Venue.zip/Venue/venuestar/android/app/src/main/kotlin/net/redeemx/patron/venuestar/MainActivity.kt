package net.redeemx.patron.venuestar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
