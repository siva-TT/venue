import 'dart:convert';
import 'package:equatable/equatable.dart';
void main()
{
print("checking");
List<ItemEntity> a = [ 
ItemModel(
      title: "New Comp create with Enhanced preview",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png",
      interest: ["food","drink"]    
      ),
ItemModel(
      title: "New Comp create with Enhanced preview1",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png",
      interest: ["food1","food"]    
      ),

ItemModel(
      title: "New Comp create with Enhanced preview",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png",
      interest: []    
      ),
];
final Map<String, List<ItemEntity>> interests = {};
for (var item in a) {  
  for (var interest in item.interest) {
    List<ItemEntity> itemInterests = [];
    itemInterests.add(item);
    if (interests.containsKey(interest)) {   
      interests[interest]?.addAll(itemInterests);      
    } else {   
    
    interests[interest]=itemInterests;
    }
    
  }
}

print(interests);

}


class ItemModel extends ItemEntity {
  const ItemModel({
    required super.title,
    required super.description,
    required super.startDate,
    required super.endDate,
    required super.previewImagePath,
    required super.interest,
  });

  factory ItemModel.fromXml(List fav) {
    List interest;
    try {
      if (fav[22] == "") {
        interest = [];
      } else {
        interest = json.decode(utf8.decode(base64.decode(fav[22])))["Interest"];
      }
    } catch (e) {
      throw Exception();
    }
    return ItemModel(
      title: fav[2],
      description: fav[3],
      startDate: fav[4],
      endDate: fav[5],
      previewImagePath: fav[6],
      interest: interest,
    );
  }

  @override
  // TODO: implement props
  List<Object?> get props =>
      [title, description, startDate, endDate, previewImagePath];
}




class ItemEntity extends Equatable {
  final String title;
  final String description;
  final String startDate;
  final String endDate;
  final String previewImagePath;
  final List interest;

  const ItemEntity({
    required this.title, 
    required this.description, 
    required this.startDate, 
    required this.endDate,
    required this.previewImagePath,
    required this.interest,
    });

  @override
  // TODO: implement props
  List<Object?> get props => [
    title,
    description,
    startDate,
    endDate,
    previewImagePath,
    interest
  ];
}

