import 'dart:convert';

import 'package:rxcommon/domain/entities/giftshops/giftshops.dart';
import 'package:rxcommon/lib.dart';

class GiftshopModel extends GiftShopEntity {
  const GiftshopModel({
    required super.title,
    required super.description,
    required super.startDate,
    required super.endDate,
    required super.previewImagePath,
    required super.transactionId,
  });

  factory GiftshopModel.fromXml(List gift) {
    return GiftshopModel(
      title: gift[1],
      description: gift[2],
      startDate: gift[6],
      endDate: gift[7],
      previewImagePath: gift[3],
      transactionId: gift[4],
    );
  }

  @override
  // TODO: implement props
  List<Object?> get props =>
      [title, description, startDate, endDate, previewImagePath,transactionId];
}
