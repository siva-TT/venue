import 'dart:convert';

import 'package:rxcommon/lib.dart';


class QuickViewModel extends QuickViewEntity {

  const QuickViewModel({
   required super.title, 
   required super.description, 
   required super.actionDescription, 
   required super.quickViewURL, 
   required super.itemType, 
   required super.transactionId, 
   required super.extUrl, 
   required super.venueSystemId, 
   required super.sortOrder
  });

  factory QuickViewModel.fromXml(List fav) {
    
    List interest;
    try {
      if (fav[22] == "") {
        interest = [];
      } else {
        interest = json.decode(utf8.decode(base64.decode(fav[22])))["Interest"];
      }
    } catch (e) {
      throw Exception();
    }
   /*  return QuickViewModel(
      transactionId: fav[1],
      title: fav[2],
      description: fav[3],
      extUrl: fav[8],
      quickViewURL:fav[10],
      itemType: fav[12],
      actionDescription:fav[15],    
      venueSystemId: fav[20],
      sortOrder: fav[24],     
    ); */
 return QuickViewModel(
      transactionId: fav[0],
      title: fav[2],
      description: fav[3],
      extUrl: fav[7],
      quickViewURL:fav[9],
      itemType: fav[11],
      actionDescription:fav[14],    
      venueSystemId: fav[19],
      sortOrder: fav[23],     
    );
  

    
  }



  @override
  // TODO: implement props
  List<Object?> get props =>
      [title, description, ];
}


/*

  1 TransactionID|
  2 TemplateID|
  3 Text|
  4 Description|
  5 StartDate|
  6 EndDate|
  7 ImageURL|
  8 ExtURL|
  9 ucIsQuickView|
  10 QuickViewURL|
  11 ucAccesslogFlag|
  12 ItemType|
  13 Category|
  14 CategoryImagePath|
  15 ItemActionDescription|
  16 EnableGrouping|
  17 EnableDescription|
  18 UpdateType|
  19 UpdateCode|
  20 VenueSystemID|
  21 IsShowInApp|
  22 IsFavourite|
  23 CompTags|
  24 Sortorder
  */