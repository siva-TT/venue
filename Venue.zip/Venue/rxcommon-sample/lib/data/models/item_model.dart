import 'dart:convert';

import 'package:rxcommon/lib.dart';

class ItemModel extends ItemEntity {
  const ItemModel({
    required super.title,
    required super.description,
    required super.startDate,
    required super.endDate,
    required super.previewImagePath,
    required super.interest,
    required super.transacId,
    required super.actionDescription,
    required super.venueid,
    required super.extUrl,
    required super.itemType,
    required super.isShowinApp,
  });

  factory ItemModel.fromXml(List fav) {
    print(fav);
    List interest;
    try {
      if (fav[22] == "") {
        interest = [];
      } else {
        interest = json.decode(utf8.decode(base64.decode(fav[22])))["Interest"];
      }
    } catch (e) {
      throw Exception();
    }
    return ItemModel(
      title: fav[2],
      description: fav[3],
      startDate: fav[4],
      endDate: fav[5],
      previewImagePath: fav[6],
      interest: interest,
      transacId: fav[0],
      actionDescription: fav[14],
      venueid: fav[19],
      extUrl: fav[7],
      itemType: fav[12],
      isShowinApp: fav[20],
    );
  }

  @override
  // TODO: implement props
  List<Object?> get props =>
      [title, description, startDate, endDate, previewImagePath];
}
