import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:rxcommon/domain/entities/giftshops/giftshops.dart';
import 'package:rxcommon/domain/repositories/giftshop_repository.dart';

import 'package:rxcommon/lib.dart';

class GiftShopRepositoryImpl implements GiftshopRepository{
  final GiftshopDataSource giftshopDataSource;
 GiftShopRepositoryImpl({required this.giftshopDataSource});
  @override
  Future<Either<Failure,List<GiftShopEntity>>> getgiftshop() async {
    try{
      final result=await giftshopDataSource.getgiftshop();
      return Right(result);    
    }on ServerException {
      return Left(ServerFailure(''));
    } on SocketException {
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
   
  }
  
}
