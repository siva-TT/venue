import 'dart:io';
import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

class ItemRepositoryImpl implements ItemRepository{
  final ItemDataSource itemDataSource;
  ItemRepositoryImpl({required this.itemDataSource});
  @override
  Future<Either<Failure,List<ItemEntity>>> getItem() async {
    try{
      final result=await itemDataSource.getItem();
      return Right(result);    
    }on ServerException {
      return Left(ServerFailure(''));
    } on SocketException {
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
   
  }
  
  @override
  Future<Either<Failure,Map<String, List<ItemEntity>>>> getInterest() async{
     try{
      final result=await itemDataSource.getInterest();
      return Right(result);    
    }on ServerException {
      return Left(ServerFailure(''));
    } on SocketException {
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
  }
  
  @override
  Future<Either<Failure, List<QuickViewEntity>>> getQuickView() async{
         try{
      final result=await itemDataSource.getQuickView();
      return Right(result);    
    }on ServerException {
      return Left(ServerFailure(''));
    } on SocketException {
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
  }
  
  @override
  Future<Either<Failure, List<ItemEntity>>> getMore() async {
    // TODO: implement getMore
    try{
      final result = await itemDataSource.getMore();
      return Right(result);
    }on ServerException{
      return Left(ServerFailure(''));
    }on SocketException{
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
  }  

    @override
  Future<Either<Failure, List<ItemEntity>>> getFnb() async {
    // TODO: implement getMore
    try{
      final result = await itemDataSource.getFnb();
      return Right(result);
    }on ServerException{
      return Left(ServerFailure(''));
    }on SocketException{
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
  }  

    @override
  Future<Either<Failure, List<ItemEntity>>> getFacilities(String itemType) async {
    // TODO: implement getMore
    try{
      final result = await itemDataSource.getFacilities(itemType);
      return Right(result);
    }on ServerException{
      return Left(ServerFailure(''));
    }on SocketException{
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
  }  
}