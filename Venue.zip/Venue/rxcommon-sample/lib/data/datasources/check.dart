import 'package:rxcommon/data/datasources/datasources.dart';

import './item_datasource.dart';
import 'package:http/http.dart' as http;
void main() async{

  /*  ItemDataSourceImpl a= ItemDataSourceImpl(client: http.Client());
  final result=await a.getFnb();
  print(result);  */

  /*   GiftshopDataSourceImpl g= GiftshopDataSourceImpl(client: http.Client());
  final gresult=await g.getgiftshop();
  print(gresult); */

   ItemDataSourceImpl a= ItemDataSourceImpl(client: http.Client());
  final result=await a.getFacilities("2|131072");
  print(result); 
}