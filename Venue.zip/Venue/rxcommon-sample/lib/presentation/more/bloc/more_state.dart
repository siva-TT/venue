part of 'more_bloc.dart';

enum MoreStatus { initial, success, error, loading }

class MoreState extends Equatable {

  final MoreStatus status;
  final List<ItemEntity> posts;

  const MoreState({
    this.status = MoreStatus.initial,
    this.posts = const <ItemEntity>[],
  });

  MoreState copyWith({ MoreStatus? status,List<ItemEntity>? posts, })
   {
    return MoreState(
      status: status ?? this.status,
      posts: posts ?? this.posts,
    );
  }
  
    @override
  String toString() {
    return '''PostState { status: $status, posts: ${posts.length} }''';
  }

  @override
  List<Object> get props => [status, posts];

}

