import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:rxcommon/domain/domain.dart';
import 'package:rxcommon/domain/usecases/items/get_more.dart';


part 'more_event.dart';
part 'more_state.dart';

class MoreBloc extends Bloc<MoreEvent, MoreState> {
  final GetMore _getMore;
MoreBloc(this._getMore) : super(MoreState()) {
    on<MoreFetched>(_onMoreFetched);
  }
  
  
 

  FutureOr<void> _onMoreFetched(
      MoreFetched event, Emitter<MoreState> emit) async {
    emit(state.copyWith( status: MoreStatus.loading, ));
    final More = await _getMore.execute();

    More.fold((failure) {  emit(state.copyWith(   status: MoreStatus.error, ));
    }, (data) {
 emit(state.copyWith(status: MoreStatus.success, posts: data));
    });
  }
}
