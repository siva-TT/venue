part of 'more_bloc.dart';



abstract class MoreEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class MoreFetched extends MoreEvent {}
