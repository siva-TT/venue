import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:rxcommon/domain/domain.dart';

part 'fnb_event.dart';
part 'fnb_state.dart';

class FnbBloc extends Bloc<FnbEvent, FnbState> {
  final GetFnb _getFnb;
FnbBloc(this._getFnb) : super(FnbState()) {
    on<FnbFetched>(_onFnbFetched);
  }
  
  
 

  FutureOr<void> _onFnbFetched(
      FnbFetched event, Emitter<FnbState> emit) async {
    emit(state.copyWith( status: FnbStatus.loading, ));
    final Fnb = await _getFnb.execute();

    Fnb.fold((failure) {  emit(state.copyWith(   status: FnbStatus.error, ));
    }, (data) {
 emit(state.copyWith(status: FnbStatus.success, posts: data));
    });
  }
}
