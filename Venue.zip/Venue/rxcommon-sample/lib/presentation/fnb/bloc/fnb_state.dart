part of 'fnb_bloc.dart';

enum FnbStatus { initial, success, error, loading }

class FnbState extends Equatable {

  final FnbStatus status;
  final List<ItemEntity> posts;

  const FnbState({
    this.status = FnbStatus.initial,
    this.posts = const <ItemEntity>[],
  });

  FnbState copyWith({ FnbStatus? status,List<ItemEntity>? posts, })
   {
    return FnbState(
      status: status ?? this.status,
      posts: posts ?? this.posts,
    );
  }
  
    @override
  String toString() {
    return '''PostState { status: $status, posts: ${posts.length} }''';
  }

  @override
  List<Object> get props => [status, posts];

}

