part of 'fnb_bloc.dart';



abstract class FnbEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class FnbFetched extends FnbEvent {}
