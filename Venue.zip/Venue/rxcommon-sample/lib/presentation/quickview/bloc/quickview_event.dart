part of 'quickview_bloc.dart';



abstract class QuickViewEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class QuickViewFetched extends QuickViewEvent {}
