part of 'quickview_bloc.dart';

enum QuickViewStatus { initial, success, error, loading }

class QuickViewState extends Equatable {
  const QuickViewState({
    this.status = QuickViewStatus.initial,
    this.posts = const <QuickViewEntity>[],
    // this.hasReachedMax = false,
  });

  final QuickViewStatus status;
  final List<QuickViewEntity> posts;
  // final bool hasReachedMax;

  QuickViewState copyWith({
    QuickViewStatus? status,
    List<QuickViewEntity>? posts,
    //   bool? hasReachedMax,
  }) {
    return QuickViewState(
      status: status ?? this.status,
      posts: posts ?? this.posts,
      //     hasReachedMax: hasReachedMax ?? this.hasReachedMax,
    );
  }

  @override
  String toString() {
    return '''PostState { status: $status, posts: ${posts.length} }''';
  }

  @override
  List<Object> get props => [status, posts];
}

