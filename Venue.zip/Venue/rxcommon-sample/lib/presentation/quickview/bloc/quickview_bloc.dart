import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:rxcommon/domain/domain.dart';


part 'quickview_event.dart';
part 'quickview_state.dart';

class QuickViewBloc extends Bloc<QuickViewEvent, QuickViewState> {
  final GetQuickView _getQuickView;
  QuickViewBloc(this._getQuickView) : super(QuickViewState()) {
    on<QuickViewFetched>(_onQuickViewFetched);
  }
  

  FutureOr<void> _onQuickViewFetched(
      QuickViewFetched event, Emitter<QuickViewState> emit) async {
    emit(state.copyWith(
      status: QuickViewStatus.loading,
    ));
    final QuickViews = await _getQuickView.execute();
 
    QuickViews.fold((failure) {
      emit(state.copyWith(
        status: QuickViewStatus.error,
      ));
    }, (data) {
      emit(state.copyWith(status: QuickViewStatus.success, posts: data));
    });
  }
}
