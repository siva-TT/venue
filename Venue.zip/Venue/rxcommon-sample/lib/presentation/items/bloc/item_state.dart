part of 'item_bloc.dart';

enum ItemStatus { initial, success, error, loading }

class ItemState extends Equatable {
  const ItemState({
    this.status = ItemStatus.initial,
    this.posts = const <ItemEntity>[],
    // this.hasReachedMax = false,
  });

  final ItemStatus status;
  final List<ItemEntity> posts;
  // final bool hasReachedMax;

  ItemState copyWith({
    ItemStatus? status,
    List<ItemEntity>? posts,
    //   bool? hasReachedMax,
  }) {
    return ItemState(
      status: status ?? this.status,
      posts: posts ?? this.posts,
      //     hasReachedMax: hasReachedMax ?? this.hasReachedMax,
    );
  }

  @override
  String toString() {
    return '''PostState { status: $status, posts: ${posts.length} }''';
  }

  @override
  List<Object> get props => [status, posts];
}

