import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:rxcommon/domain/domain.dart';

part 'item_event.dart';
part 'item_state.dart';

class ItemBloc extends Bloc<ItemEvent, ItemState> {
  final GetItem _getItem;

  // ignore: prefer_const_constructors
  ItemBloc(this._getItem) : super(ItemState()) {
    on<ItemFetched>(_onItemFetched);
    //  on<ItemRefreshed>(_onItemRefreshed);
  }

  FutureOr<void> _onItemFetched(
      ItemFetched event, Emitter<ItemState> emit) async {
    emit(state.copyWith(
      status: ItemStatus.loading,
    ));
    final Items = await _getItem.execute();
    // print("in bloc");
    //   print(Items);

    Items.fold((failure) {
      emit(state.copyWith(
        status: ItemStatus.error,
      ));
    }, (data) {
      emit(state.copyWith(status: ItemStatus.success, posts: data));
    });
  }
}
