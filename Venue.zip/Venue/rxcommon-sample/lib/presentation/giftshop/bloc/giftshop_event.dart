part of 'giftshop_bloc.dart';



abstract class GiftshopEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GiftShopFetched extends GiftshopEvent {}
