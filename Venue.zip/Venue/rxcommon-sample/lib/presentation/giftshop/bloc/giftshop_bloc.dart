import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:rxcommon/domain/domain.dart';
import 'package:rxcommon/domain/entities/giftshops/giftshop_entity.dart';


part 'giftshop_event.dart';
part 'giftshop_state.dart';

class GiftShopBloc extends Bloc<GiftshopEvent, GiftShopState> {
  final GetGiftShop _getGiftShop;
  GiftShopBloc(this._getGiftShop) : super(GiftShopState()) {
    on<GiftShopFetched>(_onGiftShopFetched);
  }
  
 

  FutureOr<void> _onGiftShopFetched(
      GiftShopFetched event, Emitter<GiftShopState> emit) async {
    emit(state.copyWith(
      status: GiftShopStatus.loading,
    ));
    final giftshops = await _getGiftShop.execute();
      giftshops.fold((failure) {
      emit(state.copyWith(
        status: GiftShopStatus.error,
      ));
    }, (data) {
      emit(state.copyWith(status: GiftShopStatus.success, posts: data));
    });
  }
}
