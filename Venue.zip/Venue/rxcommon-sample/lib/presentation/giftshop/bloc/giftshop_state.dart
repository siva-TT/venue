part of 'giftshop_bloc.dart';

enum GiftShopStatus { initial, success, error, loading }

class GiftShopState extends Equatable {
  const GiftShopState({
    this.status = GiftShopStatus.initial,
    this.posts = const <GiftShopEntity>[],
  });

  final GiftShopStatus status;
  final List<GiftShopEntity> posts;

  GiftShopState copyWith({
    GiftShopStatus? status,
    List<GiftShopEntity>? posts,
  }) {
    return GiftShopState(
      status: status ?? this.status,
      posts: posts ?? this.posts,
    );
  }

  @override
  String toString() {
    return '''PostState { status: $status, posts: ${posts.length} }''';
  }

  @override
  List<Object> get props => [status, posts];
}

