

import 'package:equatable/equatable.dart';

class WebviewState extends Equatable {
  final bool isback;

  const WebviewState(this.isback);

  @override
  List<Object> get props => [isback];
}