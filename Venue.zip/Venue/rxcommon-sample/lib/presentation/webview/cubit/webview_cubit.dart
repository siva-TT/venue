import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import 'webview_state.dart';



class WebviewCubit extends Cubit<WebviewState> {
  WebviewCubit() : super(WebviewState(false));


  Future<bool> onBack(var _controll) async {
    bool goBack;

    var value = await _controll.canGoBack(); // check webview can go back

    if (value) {
      _controll.goBack(); // perform webview back operation

      return false;
    } else {
    
      return true; //_notifier?.isBack;
    }
  }
}

