import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:rxcommon/domain/entities/items/item_entity.dart';
import 'package:rxcommon/domain/domain.dart';
import 'package:rxcommon/domain/usecases/items/get_facilities.dart';

part  'facilities_event.dart';
part  'facilities_state.dart';


class  FacilitiesBloc extends Bloc<FacilitiesEvent,  FacilitiesState> {
  final GetFacilities _getFacilities;
   FacilitiesBloc(this._getFacilities) : super(FacilitiesState()) {
    on<FacilitiesFetched>(_onFacilitiesFetched);
  //  on<ItemRefreshed>(_onItemRefreshed);
  }
  


  FutureOr<void> _onFacilitiesFetched( FacilitiesFetched event, Emitter< FacilitiesState> emit) async {
        final itemType = event.itemType;
    emit(state.copyWith(
      status:  FacilitiesStatus.loading,
    ));
    final Items = await _getFacilities.execute(itemType);
   
    Items.fold((failure) {
      emit(state.copyWith(
        status:  FacilitiesStatus.error,
      ));
    }, (data) {
      emit(state.copyWith(status:  FacilitiesStatus.success, posts: data));
    });
  }
}
