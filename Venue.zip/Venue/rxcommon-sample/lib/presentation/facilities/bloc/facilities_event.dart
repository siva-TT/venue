part of 'facilities_bloc.dart';



abstract class  FacilitiesEvent extends Equatable {
  const FacilitiesEvent();

}

class FacilitiesFetched extends FacilitiesEvent {
  late final String itemType;

  FacilitiesFetched(this.itemType);

  @override
  List<Object?> get props => [itemType];
}