part of 'facilities_bloc.dart';


enum FacilitiesStatus { initial, success, error, loading }

class FacilitiesState extends Equatable {
  const FacilitiesState({
    this.status = FacilitiesStatus.initial,
    this.posts = const <ItemEntity>[],
  
  });

  final FacilitiesStatus status;
  final List<ItemEntity> posts;

  FacilitiesState copyWith({
    FacilitiesStatus? status,
    List<ItemEntity>? posts,
  }) {
    return FacilitiesState(
      status: status ?? this.status,
      posts: posts ?? this.posts,
    );
  }

  @override
  String toString() {
    return '''Facilities { status: $status, posts: ${posts.length} }''';
  }

  @override
  List<Object> get props => [status, posts];
}

