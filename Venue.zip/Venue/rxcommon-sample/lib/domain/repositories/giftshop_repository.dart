import 'package:dartz/dartz.dart';
import 'package:rxcommon/domain/entities/giftshops/giftshop_entity.dart';

import 'package:rxcommon/lib.dart';

abstract class GiftshopRepository{
  Future<Either<Failure,List<GiftShopEntity>>> getgiftshop();
}