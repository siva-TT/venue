import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

abstract class ItemRepository{
  Future<Either<Failure,List<ItemEntity>>> getItem();
  Future<Either<Failure,List<QuickViewEntity>>> getQuickView();
  Future<Either<Failure,Map<String, List<ItemEntity>>>> getInterest();
  Future<Either<Failure, List<ItemEntity>>> getMore();
  Future<Either<Failure, List<ItemEntity>>> getFnb();
  Future<Either<Failure, List<ItemEntity>>> getFacilities(String itemType);
}