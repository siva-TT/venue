import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

class GetItem {
  final ItemRepository repository;

  GetItem({required this.repository});

  Future<Either<Failure, List<ItemEntity>>> execute() {
    return repository.getItem();
  }
}
