import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

class GetInterests{
  final ItemRepository repository;

  GetInterests({required this.repository});

  Future<Either<Failure,Map<String, List<ItemEntity>>>> execute(){
    return repository.getInterest();
    
  }
}