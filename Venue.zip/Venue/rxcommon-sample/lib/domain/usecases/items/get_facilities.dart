

import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

class GetFacilities{
  final ItemRepository repository;
 
  GetFacilities({required this.repository});

  Future<Either<Failure,List<ItemEntity>>> execute(String itemType){

    return repository.getFacilities(itemType);
  }
}