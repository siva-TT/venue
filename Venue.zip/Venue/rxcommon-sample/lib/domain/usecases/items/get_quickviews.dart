import 'package:dartz/dartz.dart';
import 'package:rxcommon/domain/entities/items/quickview_entity.dart';

import 'package:rxcommon/lib.dart';

class GetQuickView{
  final ItemRepository repository;

  GetQuickView({required this.repository});

  Future<Either<Failure,List<QuickViewEntity>>> execute(){
    return repository.getQuickView();
  }
}