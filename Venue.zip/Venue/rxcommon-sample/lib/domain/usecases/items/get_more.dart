

import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

class GetMore{
  final ItemRepository repository;

  GetMore({required this.repository});

  Future<Either<Failure,List<ItemEntity>>> execute(){
    return repository.getMore();
  }
}