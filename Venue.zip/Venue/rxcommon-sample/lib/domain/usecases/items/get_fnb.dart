

import 'package:dartz/dartz.dart';

import 'package:rxcommon/lib.dart';

class GetFnb{
  final ItemRepository repository;

  GetFnb({required this.repository});

  Future<Either<Failure,List<ItemEntity>>> execute(){
    return repository.getFnb();
  }
}