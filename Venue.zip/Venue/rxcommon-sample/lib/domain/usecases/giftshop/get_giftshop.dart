import 'package:dartz/dartz.dart';
import 'package:rxcommon/domain/repositories/giftshop_repository.dart';

import 'package:rxcommon/lib.dart';

import '../../entities/giftshops/giftshop_entity.dart';

class GetGiftShop{
  final GiftshopRepository repository;

  GetGiftShop({required this.repository});

  Future<Either<Failure,List<GiftShopEntity>>> execute(){
    return repository.getgiftshop();
  }
}