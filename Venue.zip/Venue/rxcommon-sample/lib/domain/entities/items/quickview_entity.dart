import 'package:equatable/equatable.dart';

class QuickViewEntity extends Equatable {
  final String title;
  final String description;
  final String actionDescription;
  final String quickViewURL;
  final String itemType;
  final String transactionId;
  final String extUrl;
  final String venueSystemId;
  final String sortOrder;

const QuickViewEntity({
    required this.title, 
    required this.description, 
    required this.actionDescription, 
    required this.quickViewURL,
    required this.itemType,
    required this.transactionId,
    required this.extUrl,
    required this.venueSystemId,
    required this.sortOrder,
    });

  //const QuickViewEntity(  required.this.title, this.description, this.actionDescription, this.quickViewURL, this.itemType, this.transactionId, this.extUrl, this.venueSystemId, this.sortOrder);

 
  @override
  // TODO: implement props
  List<Object?> get props => [
    title,
    description,
    actionDescription,
    quickViewURL,
    itemType,
    transactionId,
    extUrl,
    venueSystemId,
    sortOrder    
  ];
}


