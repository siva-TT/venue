import 'package:equatable/equatable.dart';

class ItemEntity extends Equatable {
  final String title;
  final String description;
  final String startDate;
  final String endDate;
  final String previewImagePath;
  final List interest;
  final String transacId;
  final String actionDescription;
  final String venueid;
  final String extUrl;
  final String itemType;
  final String isShowinApp;

  const ItemEntity({
    required this.title, 
    required this.description, 
    required this.startDate, 
    required this.endDate,
    required this.previewImagePath,
    required this.interest,
    required this.transacId,
    required this.actionDescription,
    required this.venueid,
    required this.extUrl,
    required this.itemType,
    required this.isShowinApp,
    });


  @override
  // TODO: implement props
  List<Object?> get props => [
    title,
    description,
    startDate,
    endDate,
    previewImagePath,
    interest,
    transacId,
    actionDescription,
    venueid,
    extUrl,
    itemType,
    isShowinApp
  ];
}
