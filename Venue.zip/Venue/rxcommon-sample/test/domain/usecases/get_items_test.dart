import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

import 'package:rxcommon/data/data.dart';
import 'package:rxcommon/domain/domain.dart';

import '../../data/datasources/item_datasource_test.mocks.dart';

void main(){

  late MockItemRepository itemRepository;
  late GetItem getItem;

  setUp((() {
    itemRepository=MockItemRepository();
    getItem=GetItem(repository:itemRepository);
  }));

  ItemModel fv1 = ItemModel(
      title: "New Comp create with Enhanced preview1",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png", interest: ["Eat","Drinl"]);

  ItemModel fv2 = ItemModel(
      title: "New Comp with Eticket and NextSwipe",
      description: "Comp with Eticket and NextSwipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath: "", interest: ["Eat","Drinl"]);

  List<ItemEntity> ItemPosts = [];

  ItemPosts.add(fv1);
  ItemPosts.add(fv2);
  group('get item list from the repo', (() {
    test('get data',()async {
      when(itemRepository.getItem()).thenAnswer((_) async => Right(ItemPosts));
      final result= await getItem.execute();     
       expect(result, equals(Right(ItemPosts)));

    });

     test('Server Failure',()async {
      when(itemRepository.getItem()).thenAnswer((_) async => Left(ServerFailure('')));
      final result= await getItem.execute();   
      print(result);  
      expect(result, equals(Left(ServerFailure(''))));

    });
  }));
  
  
}