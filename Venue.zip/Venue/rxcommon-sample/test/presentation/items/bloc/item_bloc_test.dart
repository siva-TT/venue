import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:rxcommon/lib.dart';

import './item_bloc_test.mocks.dart';
@GenerateMocks([GetItem])
void main(){

  late MockGetItem _getItem;
  late ItemBloc itemBloc;

  

   ItemModel fv1 = ItemModel(
      title: "New Comp create with Enhanced preview1",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png", interest: ["Eat","Drinl"]);

  ItemModel fv2 = ItemModel(
      title: "New Comp with Eticket and NextSwipe",
      description: "Comp with Eticket and NextSwipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath: "", interest: ["Eat","Drinl"]);

  List<ItemEntity> ItemPosts = [];

  ItemPosts.add(fv1);
  ItemPosts.add(fv2);

  setUp((() {
    _getItem=MockGetItem();
    itemBloc=ItemBloc(_getItem);
  }));

  test(
    'initial state should be empty',
    () {
      expect(itemBloc.state.status, ItemStatus.initial );
    },
  );

    blocTest<ItemBloc, ItemState>(
    'should emit [loading, has data] when data is gotten successfully',
    build: () {
      when(_getItem.execute())
          .thenAnswer((_) async => Right(ItemPosts));
      return itemBloc;
    },
    act: (bloc) => bloc.add(ItemFetched()),
    wait: const Duration(milliseconds: 500),
    expect: () => [
      ItemState(
        status:ItemStatus.loading,
      ),
      
      ItemState(
        status:ItemStatus.success,
        posts: ItemPosts
        )
    ],
    verify: (bloc) {
      verify(_getItem.execute());
    },
  );

    blocTest<ItemBloc, ItemState>(
    'should emit error',
    build: () {
      when(_getItem.execute())
          .thenAnswer((_) async => Left(ServerFailure(" failure")));
      return itemBloc;
    },
    act: (bloc) => bloc.add(ItemFetched()),
    wait: const Duration(milliseconds: 500),
    expect: () => [
      ItemState(
        status:ItemStatus.loading,
      ),
      
      ItemState(
        status:ItemStatus.error,
      
        )
    ],
    verify: (bloc) {
      verify(_getItem.execute());
    },
  );
}