import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

import 'package:rxcommon/data/data.dart';
import 'package:rxcommon/domain/domain.dart';

import '../datasources/item_datasource_test.mocks.dart';

void main()
{
 late MockItemDataSource mockItemDataSource;
 late ItemRepositoryImpl itemRepository;

 setUp((){
  mockItemDataSource=MockItemDataSource();
  itemRepository=ItemRepositoryImpl(itemDataSource:mockItemDataSource);
 });
 ItemModel fv1 = ItemModel(
      title: "New Comp create with Enhanced preview1",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png", interest: ["Eat","Drinl"]);

  ItemModel fv2 = ItemModel(
      title: "New Comp with Eticket and NextSwipe",
      description: "Comp with Eticket and NextSwipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath: "", interest: ["Eat","Drinl"]);

  List<ItemEntity> ItemPosts = [];
  ItemPosts.add(fv1);
  ItemPosts.add(fv2);

 

  group('get items',(() {
    test('should return correct items',(() async {
      when(mockItemDataSource.getItem()).thenAnswer((_) async => ItemPosts);
       final result = await itemRepository.getItem();
       verify(mockItemDataSource.getItem());
       expect(result,Right(ItemPosts));
    }));

      test('server failure',(() async {
      when(mockItemDataSource.getItem()).thenThrow(ServerException());
       final result = await itemRepository.getItem();
       verify(mockItemDataSource.getItem());
       expect(result,Left(ServerFailure('')));
    }));

     test('network failure',(() async {
      when(mockItemDataSource.getItem()).thenThrow(SocketException('Failed to connect to the network'));
       final result = await itemRepository.getItem();
       print(verify(mockItemDataSource.getItem()));
       expect(result,Left(ConnectionFailure('Failed to connect to the network')));
    }));
    
  }));

}