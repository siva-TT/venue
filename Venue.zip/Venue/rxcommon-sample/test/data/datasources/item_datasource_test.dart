import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:http/http.dart' as http;

import 'package:rxcommon/lib.dart';
import './item_datasource_test.mocks.dart';

@GenerateMocks([
  ItemRepository,
  ItemDataSource,
], customMocks: [
  MockSpec<http.Client>(as: #MockHttpClient),
 
])
void main() {
  late MockHttpClient mockHttpClient;
  late ItemDataSourceImpl ItemDataSource;
  var dir = Directory.current.path;
  var xml =
      '<?xml version="1.0" encoding="utf-8"?><RXGateway xmlns="http://redeemx.net/" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><H1>venuemetro</H1><H2>501</H2><H3>10000027376220401172330382</H3><H4>2022-04-01T17:23:30</H4><H5>aOHI+Jxyq35DLyONqJDzPyKAfwx5szT8uARH9S8PQMyVCeLdsvdOPunPpynnNSsr</H5><H6>10000027417</H6><H7>1</H7><D3>10000027417</D3><D8>RXMEMBER|PROMOTION||217309|SILVER|</D8><D10>1</D10><D13>231473</D13><F1>RXMEMBER|1.7|Version 1.7 C13.81 G7.2 B0.3</F1><F2>10000027376|RXMEMBER|12345678</F2><F3>2|1</F3></RXGateway>';

  ItemModel fv1 = ItemModel(
      title: "New Comp create with Enhanced preview",
      description: "Next Swipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath:
          "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png", interest: ["Eat","Drinl"]);

  ItemModel fv2 = ItemModel(
      title: "New Comp with Eticket and NextSwipe",
      description: "Comp with Eticket and NextSwipe",
      startDate: "2022-07-06T00:00:00",
      endDate: "2022-07-06T23:59:59",
      previewImagePath: "", interest: ["Eat","Drinl"]);

  List<ItemEntity> ItemPosts = [];
  ItemPosts.add(fv1);
  ItemPosts.add(fv2);

  setUp(() {
    mockHttpClient = MockHttpClient();
    ItemDataSource = ItemDataSourceImpl(client: mockHttpClient);
  });
  group("get Item", () {
    test("get items", () async {
      when(mockHttpClient.post(
        Uri.parse("http://venuemetro.redeemx.net/redeemx.svc/"),
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
        },
        body: xml,
      )).thenAnswer(
        (_) async => http.Response(
            File('$dir/test/data/datasources/item.xml').readAsStringSync(),
            200),
      );
      final result = await ItemDataSource.getItem();

      expect(result, equals(ItemPosts));
    });

    test('Server Exception 404', (() async {
      when(mockHttpClient.post(
        Uri.parse("http://venuemetro.redeemx.net/redeemx.svc/"),
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
        },
        body: xml,
      )).thenAnswer(
        (_) async => http.Response("not found", 404),
      );
      final result = ItemDataSource.getItem();

      expect(() => result, throwsA(isA<Exception>()));
    }));
  });
}
