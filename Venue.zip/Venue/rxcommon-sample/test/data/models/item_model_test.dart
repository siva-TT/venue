import 'package:flutter_test/flutter_test.dart';

import 'package:rxcommon/data/data.dart';


void main() {
final favModel = ItemModel(title: "New Comp create with Enhanced preview", description:"Next Swipe" , startDate: "2022-07-06T00:00:00", endDate: "2022-07-06T23:59:59", previewImagePath: "https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png", interest: ["Eat","Drinl"]);
List items=["32642","1","New Comp create with Enhanced preview","Next Swipe","2022-07-06T00:00:00","2022-07-06T23:59:59","https://rxdevds.blob.core.windows.net/venuemetro/MemberAppTransactions/32642/62c4f1b69d7a1.png","","","","PROMOTION","July 2022","","","","","","","venuemetro","","",""];
 group('fromxml',(){

  test('from xml',(() {
    expect(ItemModel.fromXml(items),equals(favModel));
  }));

 });
}